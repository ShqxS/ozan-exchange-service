package com.ozan.exchange;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OzanExchangeServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
