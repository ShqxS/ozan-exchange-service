package com.ozan.exchange.client.response;

public record CurrencyConvertResponse (boolean success, Double result) {}

